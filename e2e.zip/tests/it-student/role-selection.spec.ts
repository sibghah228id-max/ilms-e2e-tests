import { test, expect } from '@playwright/test';
import { RoleSelectionPage, ROLES, IT_STUDENT_BENEFITS } from '../pages/create-account.page';

test.describe('Create account — role selection', () => {
  let rolePage: RoleSelectionPage;

  test.beforeEach(async ({ page }) => {
    rolePage = new RoleSelectionPage(page);
    await rolePage.goto();
  });

  test('shows the IT Student option', async () => {
    await expect(rolePage.roleCard('IT Student')).toBeVisible();
  });

  test('no role is selected and Create Account is disabled until a selection is made', async () => {
    const borders = await Promise.all(ROLES.map((r) => rolePage.borderColor(r)));
    expect(new Set(borders).size, 'all role cards should look identical (unselected) on load').toBe(1);
    await expect(rolePage.createAccountButton).toBeDisabled();
  });

  test('selected IT Student card gets a distinct border colour', async () => {
    // Academia is never clicked, so it provides the unselected reference border.
    const unselected = await rolePage.borderColor('Academia');

    // Select another role first so IT Student starts from an unselected state.
    await rolePage.roleCard('IT Professional').click();
    await expect.poll(() => rolePage.borderColor('IT Student')).toBe(unselected);

    await rolePage.roleCard('IT Student').click();

    // Cards animate their border (transition-all), so poll until it settles.
    await expect.poll(() => rolePage.borderColor('IT Student')).not.toBe(unselected);
    await expect.poll(() => rolePage.borderColor('IT Professional')).toBe(unselected);
  });

  test('selecting IT Student shows all benefits in the checklist', async ({ page }) => {
    await rolePage.roleCard('IT Student').click();

    for (const benefit of IT_STUDENT_BENEFITS) {
      await expect(page.getByText(benefit, { exact: true })).toBeVisible();
    }
  });

  test('selecting IT Student and clicking Create Account opens the student form', async ({ page }) => {
    await rolePage.roleCard('IT Student').click();
    await expect(rolePage.createAccountButton).toBeEnabled();

    await rolePage.createAccountButton.click();

    await expect(page).toHaveURL(/\/create-account\/student\/?$/);
    await expect(page.locator('#name')).toBeVisible();
  });
});
