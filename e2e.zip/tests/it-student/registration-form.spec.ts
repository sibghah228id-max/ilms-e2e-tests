import { test, expect } from '@playwright/test';
import { StudentRegistrationPage, dateYearsAgo } from '../pages/create-account.page';

// Field-level checks only — nothing here produces a valid submission.
test.describe('IT Student registration form — fields & validation', () => {
  let form: StudentRegistrationPage;

  test.beforeEach(async ({ page }) => {
    form = new StudentRegistrationPage(page);
    await form.goto();
  });

  test('all required fields are present with the expected placeholders', async () => {
    await expect(form.name).toHaveAttribute('placeholder', 'Enter your full name');
    await expect(form.cnic).toHaveAttribute('placeholder', 'Enter 13-digit CNIC (no dashes)');
    await expect(form.dateOfBirth).toHaveAttribute('type', 'date');
    await expect(form.dateOfBirth).toHaveAttribute('placeholder', 'DD/MM/YYYY');
    await expect(form.email).toHaveAttribute('placeholder', 'Enter your email address');

    for (const field of [form.name, form.cnic, form.dateOfBirth, form.email, form.phone, form.password, form.confirmPassword, form.university]) {
      await expect(field).toHaveAttribute('required', '');
    }
  });

  test('submitting empty shows required errors', async () => {
    await form.submitButton.click();

    await expect(form.error('Name is required')).toBeVisible();
    await expect(form.error('Date of birth is required')).toBeVisible();
    await expect(form.error('Email is required')).toBeVisible();
    await expect(form.error('Phone number is required')).toBeVisible();
    await expect(form.error('University is required')).toBeVisible();
    await expect(form.error(/cnic/i).first()).toBeVisible();
  });

  test('name accepts alphabets only', async () => {
    await form.name.fill('Naveed123');
    await form.submitButton.click();
    await expect(form.error('Name must contain only English letters')).toBeVisible();

    await form.name.fill('nAveed Ullah');
    await form.submitButton.click();
    await expect(form.error('Name must contain only English letters')).toBeHidden();
  });

  test('CNIC accepts digits only, max 13', async () => {
    await form.cnic.pressSequentially('12ab-34');
    await expect(form.cnic).toHaveValue('1234');

    await form.cnic.fill('');
    await form.cnic.pressSequentially('12345678901234567');
    await expect(form.cnic).toHaveValue('1234567890123');
  });

  test('CNIC shorter than 13 digits shows an error', async () => {
    await form.cnic.fill('12345');
    await form.submitButton.click();
    await expect(form.error('CNIC must be 13 digits')).toBeVisible();
  });

  test('date of birth: user must be at least 15 years old', async () => {
    // One day short of 15 → rejected
    await form.dateOfBirth.fill(dateYearsAgo(15, 1));
    await form.submitButton.click();
    await expect(form.error(/at least 15 years old/i)).toBeVisible();

    // Exactly 15 → accepted
    await form.dateOfBirth.fill(dateYearsAgo(15));
    await form.submitButton.click();
    await expect(form.error(/at least \d+ years old/i)).toBeHidden();
  });

  test('gender options are Male, Female, Other', async () => {
    const radios = form.genderGroup.getByRole('radio');
    await expect(radios).toHaveCount(3);
    await expect(form.genderGroup).toContainText('Male');
    await expect(form.genderGroup).toContainText('Female');
    await expect(form.genderGroup).toContainText('Other');
  });

  test('email must be a valid format', async () => {
    await form.email.fill('bad-email');
    await form.submitButton.click();
    await expect(form.error('Enter a valid email address')).toBeVisible();

    await form.email.fill('valid@example.com');
    await form.submitButton.click();
    await expect(form.error('Enter a valid email address')).toBeHidden();
  });

  test('phone accepts digits only, max 10', async () => {
    await form.phone.pressSequentially('30a2-85');
    await expect(form.phone).toHaveValue('30285');

    await form.phone.fill('');
    await form.phone.pressSequentially('302850797312');
    await expect(form.phone).toHaveValue('3028507973');
  });

  test('phone with fewer than 10 digits shows an error', async () => {
    await form.phone.fill('302850797');
    await form.submitButton.click();
    await expect(form.error(/phone/i).first()).toBeVisible();
  });

  test('password must be at least 10 characters', async () => {
    await form.password.fill('Pass@1234'); // 9
    await form.submitButton.click();
    await expect(form.error('Password must be at least 10 characters').first()).toBeVisible();

    await form.password.fill('Pass@12345'); // 10
    await form.confirmPassword.fill('Pass@12345');
    await form.submitButton.click();
    await expect(form.error(/password must be at least/i)).toHaveCount(0);
  });

  test('password and confirm password are hidden and revealed by the eye button', async () => {
    for (const input of [form.password, form.confirmPassword]) {
      await input.fill('Password@1122');
      await expect(input).toHaveAttribute('type', 'password');

      await form.eyeButton(input).click();
      await expect(input).toHaveAttribute('type', 'text');

      await form.eyeButton(input).click();
      await expect(input).toHaveAttribute('type', 'password');
    }
  });

  test('confirm password must match password', async () => {
    await form.password.fill('Password@1122');
    await form.confirmPassword.fill('Password@1123');
    await form.submitButton.click();
    await expect(form.error(/match/i)).toBeVisible();
  });

  test('university is searchable: "Abdul" lists Shah Abdul Latif and Abdul Wali Khan', async ({ page }) => {
    await form.university.fill('Abdul');

    await expect(page.getByRole('option', { name: /Shah Abdul Latif University/i })).toBeVisible();
    await expect(page.getByRole('option', { name: /Abdul Wali (Khan )?University/i })).toBeVisible();
  });
});
