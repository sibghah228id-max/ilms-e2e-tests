import { test, expect } from '@playwright/test';
import { StudentRegistrationPage, type StudentData } from '../pages/create-account.page';

/**
 * These tests SUBMIT the form and create a real account on the target environment.
 * They are order-dependent and not re-runnable with the same data:
 *   - "invalid phone" runs first, so a duplicate-email error can't mask the phone error;
 *   - "valid registration" creates the account;
 *   - "duplicate email" relies on that account existing.
 * Override REG_EMAIL / REG_CNIC to re-run against a fresh identity.
 */
const EMAIL = process.env.REG_EMAIL ?? 'naveed.test@gmail.com';
const CNIC = process.env.REG_CNIC ?? '3740429658837';

const validStudent: StudentData = {
  name: 'nAveed Ullah',
  cnic: CNIC,
  dateOfBirth: '1999-07-09',
  gender: 'Male',
  email: EMAIL,
  phone: '3028507973',
  password: 'Password@1122',
  confirmPassword: 'Password@1122',
  university: 'Abdul Wali Khan University',
};

test.describe.serial('IT Student registration — submission', () => {
  let form: StudentRegistrationPage;

  test.beforeEach(async ({ page }) => {
    form = new StudentRegistrationPage(page);
    await form.goto();
  });

  test('case 2: 9-digit phone number shows a phone error', async ({ page }) => {
    await form.fill({ ...validStudent, phone: '302850797' });
    await form.submitButton.click();

    await expect(form.error(/phone/i).first()).toBeVisible();
    await expect(page).toHaveURL(/\/create-account\/student\/?$/);
  });

  test('case 1: valid data registers the user and lands on the dashboard', async ({ page }) => {
    await form.fill(validStudent);
    await form.submitButton.click();

    await expect(page).toHaveURL(/\/dashboard/, { timeout: 30_000 });
  });

  test('case 3: already-registered email shows "email already exists"', async ({ page }) => {
    await form.fill({ ...validStudent, phone: '3028507974' });
    await form.submitButton.click();

    await expect(form.error(/email.*(already|exists|taken)/i).first()).toBeVisible({ timeout: 15_000 });
    await expect(page).toHaveURL(/\/create-account\/student\/?$/);
  });
});
